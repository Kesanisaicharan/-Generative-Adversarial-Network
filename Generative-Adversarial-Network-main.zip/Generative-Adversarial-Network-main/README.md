This GAN model is trained using the MINST dataset(70000 images).
This model can generate understandable images of numbers ranging from 0 to 9.
